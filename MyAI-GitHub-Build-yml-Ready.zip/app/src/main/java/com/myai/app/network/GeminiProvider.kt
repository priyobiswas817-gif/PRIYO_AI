package com.myai.app.network

import com.myai.app.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
private data class Part(val text: String)
@Serializable
private data class Content(val role: String? = null, val parts: List<Part>)
@Serializable
private data class GenerateRequest(val contents: List<Content>)

class GeminiProvider : AiProvider {
    private val apiKey = BuildConfig.GEMINI_API_KEY
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    override fun isConfigured(): Boolean = apiKey.isNotBlank()

    override fun streamReply(history: List<ChatTurn>, modelId: String): Flow<StreamEvent> = flow {
        if (!isConfigured()) {
            emit(StreamEvent.Error("Gemini API key is not configured", isAuthError = true))
            return@flow
        }
        val contents = history.map { turn ->
            val role = if (turn.role == "assistant") "model" else "user"
            Content(role = role, parts = listOf(Part(turn.content)))
        }
        val body = json.encodeToString(GenerateRequest.serializer(), GenerateRequest(contents))
        val model = if (modelId.isBlank()) "gemini-3.7-flash" else modelId
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .addHeader("x-goog-api-key", apiKey)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val msg = try {
                        json.parseToJsonElement(raw).jsonObject["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content
                    } catch (_: Exception) { null }
                    emit(StreamEvent.Error(msg ?: "Gemini API error (${response.code})", response.code == 401 || response.code == 403))
                    return@flow
                }
                val root: JsonElement = json.parseToJsonElement(raw)
                val text = root.jsonObject["candidates"]?.jsonArray?.firstOrNull()
                    ?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray
                    ?.joinToString("") { it.jsonObject["text"]?.jsonPrimitive?.content.orEmpty() }
                    .orEmpty()
                if (text.isBlank()) emit(StreamEvent.Error("Gemini returned an empty response"))
                else emit(StreamEvent.Delta(text))
                emit(StreamEvent.Done)
            }
        } catch (e: Exception) {
            emit(StreamEvent.Error(e.message ?: "Network error"))
        }
    }
}
