package com.myai.app.data

import android.content.Context
import com.myai.app.network.AiProvider
import com.myai.app.network.GeminiProvider
import com.myai.app.repository.ChatRepository

/**
 * Lightweight manual dependency container (no DI framework needed for this app size).
 */
class AppContainer(context: Context) {
    val settingsStore = SettingsStore(context)
    val database = ChatDatabase.getInstance(context)
    val aiProvider: AiProvider = GeminiProvider()
    val chatRepository = ChatRepository(database.chatDao(), aiProvider)
}
