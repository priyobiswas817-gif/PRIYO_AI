package com.myai.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.myai.app.data.AiModel
import com.myai.app.data.ChatMessageEntity
import com.myai.app.data.ChatSession
import com.myai.app.data.SettingsStore
import com.myai.app.network.ChatTurn
import com.myai.app.network.StreamEvent
import com.myai.app.repository.ChatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val currentSessionId: Long? = null,
    val messages: List<ChatMessageEntity> = emptyList(),
    val isGenerating: Boolean = false,
    val errorMessage: String? = null,
    val model: AiModel = AiModel.GEMINI_37_FLASH
)

class ChatViewModel(
    private val repository: ChatRepository,
    private val settingsStore: SettingsStore
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState

    val sessions: StateFlow<List<ChatSession>> =
        repository.observeSessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var messagesJob: Job? = null
    private var generationJob: Job? = null
    private var lastFailedPrompt: String? = null

    init {
        viewModelScope.launch {
            settingsStore.model.collect { model -> _uiState.update { it.copy(model = model) } }
        }
        viewModelScope.launch {
            // Start with the most recent session, or create one if none exist.
            sessions.collect { list ->
                if (_uiState.value.currentSessionId == null) {
                    val target = list.firstOrNull()?.id ?: repository.createSession()
                    selectSession(target)
                }
            }
        }
    }

    fun selectSession(sessionId: Long) {
        messagesJob?.cancel()
        _uiState.update { it.copy(currentSessionId = sessionId, errorMessage = null) }
        messagesJob = viewModelScope.launch {
            repository.observeMessages(sessionId).collect { msgs ->
                _uiState.update { it.copy(messages = msgs) }
            }
        }
    }

    fun newChat() {
        viewModelScope.launch {
            val id = repository.createSession()
            selectSession(id)
        }
    }

    fun renameSession(sessionId: Long, title: String) {
        viewModelScope.launch { repository.renameSession(sessionId, title) }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_uiState.value.currentSessionId == sessionId) {
                val next = sessions.value.firstOrNull { it.id != sessionId }?.id ?: repository.createSession()
                selectSession(next)
            }
        }
    }

    fun clearCurrentChat() {
        val sessionId = _uiState.value.currentSessionId ?: return
        viewModelScope.launch { repository.clearMessages(sessionId) }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            val id = repository.createSession()
            selectSession(id)
        }
    }

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val sessionId = _uiState.value.currentSessionId ?: return
        lastFailedPrompt = null

        generationJob = viewModelScope.launch {
            repository.addUserMessage(sessionId, trimmed)
            maybeAutoTitle(sessionId, trimmed)
            runGeneration(sessionId)
        }
    }

    fun regenerateLast() {
        val sessionId = _uiState.value.currentSessionId ?: return
        val msgs = _uiState.value.messages
        val lastUser = msgs.lastOrNull { it.role == "user" } ?: return
        viewModelScope.launch {
            // Remove the last assistant message (if any) before regenerating.
            msgs.lastOrNull { it.role == "assistant" }?.let { repository.deleteMessage(it) }
            runGeneration(sessionId)
        }
    }

    fun retryLastFailed() {
        val sessionId = _uiState.value.currentSessionId ?: return
        _uiState.update { it.copy(errorMessage = null) }
        viewModelScope.launch { runGeneration(sessionId) }
    }

    fun stopGenerating() {
        generationJob?.cancel()
        _uiState.update { it.copy(isGenerating = false) }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private suspend fun maybeAutoTitle(sessionId: Long, firstUserText: String) {
        val session = sessions.value.find { it.id == sessionId } ?: return
        if (session.title == "New Chat") {
            val title = firstUserText.take(40).let { if (firstUserText.length > 40) "$it…" else it }
            repository.renameSession(sessionId, title)
        }
    }

    private suspend fun runGeneration(sessionId: Long) {
        _uiState.update { it.copy(isGenerating = true, errorMessage = null) }

        val history = repository.getHistoryOnce(sessionId)
            .filter { !it.isError }
            .map { ChatTurn(it.role, it.content) }

        val assistantId = repository.addAssistantMessage(sessionId, "")
        val builder = StringBuilder()

        try {
            repository.streamAssistantReply(history, _uiState.value.model.id).collect { event ->
                when (event) {
                    is StreamEvent.Delta -> {
                        builder.append(event.textChunk)
                        updateAssistantMessage(sessionId, assistantId, builder.toString())
                    }
                    is StreamEvent.Done -> {
                        _uiState.update { it.copy(isGenerating = false) }
                    }
                    is StreamEvent.Error -> {
                        val friendly = if (event.isAuthError) "not_configured" else "network_error"
                        if (builder.isEmpty()) {
                            updateAssistantMessage(sessionId, assistantId, event.message, isError = true)
                        }
                        _uiState.update { it.copy(isGenerating = false, errorMessage = friendly) }
                    }
                }
            }
        } catch (t: Throwable) {
            if (builder.isEmpty()) {
                updateAssistantMessage(sessionId, assistantId, t.message ?: "Error", isError = true)
            }
            _uiState.update { it.copy(isGenerating = false, errorMessage = "network_error") }
        }
    }

    private suspend fun updateAssistantMessage(
        sessionId: Long,
        messageId: Long,
        content: String,
        isError: Boolean = false
    ) {
        val current = repository.getHistoryOnce(sessionId).find { it.id == messageId } ?: return
        repository.updateMessageContent(current, content, isError)
    }
}
