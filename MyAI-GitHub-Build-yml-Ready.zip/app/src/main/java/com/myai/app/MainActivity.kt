package com.myai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.myai.app.data.AppTheme
import com.myai.app.ui.ChatScreen
import com.myai.app.ui.ChatViewModel
import com.myai.app.ui.ChatViewModelFactory
import com.myai.app.ui.HistoryScreen
import com.myai.app.ui.SettingsScreen
import com.myai.app.ui.theme.MyAiTheme

class MainActivity : ComponentActivity() {

    private val container by lazy { (application as MyAiApplication).container }

    private val chatViewModel: ChatViewModel by viewModels { ChatViewModelFactory(container) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val appTheme by container.settingsStore.theme.collectAsState(initial = AppTheme.SYSTEM)

            MyAiTheme(appTheme = appTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = "chat") {
                        composable("chat") {
                            ChatScreen(
                                viewModel = chatViewModel,
                                onOpenHistory = { navController.navigate("history") },
                                onOpenSettings = { navController.navigate("settings") }
                            )
                        }
                        composable("history") {
                            HistoryScreen(
                                viewModel = chatViewModel,
                                onBack = { navController.popBackStack() },
                                onSessionSelected = { navController.popBackStack("chat", inclusive = false) }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                container = container,
                                viewModel = chatViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
