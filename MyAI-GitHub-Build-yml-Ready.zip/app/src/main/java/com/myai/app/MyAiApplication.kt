package com.myai.app

import android.app.Application
import com.myai.app.data.AppContainer

class MyAiApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
