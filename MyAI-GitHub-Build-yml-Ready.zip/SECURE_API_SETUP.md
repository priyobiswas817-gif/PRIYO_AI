# Secure Gemini API setup

Architecture:
Android APK -> HTTPS Backend -> Gemini API

The Gemini API key stays ONLY on the backend as `GEMINI_API_KEY`.
Never put it in Kotlin/Java/XML/Gradle/BuildConfig or the APK.

1. Deploy the `backend/` folder to a Node.js host.
2. Set environment variable `GEMINI_API_KEY` to a NEW Gemini key.
3. Set `GEMINI_MODEL=gemini-2.5-flash`.
4. Use HTTPS.
5. Configure the Android app to call your backend `/chat` endpoint.

GitHub Actions should build the APK without injecting the Gemini key into it.
If GitHub Actions deploys the backend, store the key as a repository Secret named
`GEMINI_API_KEY` and use it only during server deployment.

Important: a secret cannot be made unextractable if shipped inside an APK.
This design avoids shipping the Gemini key to the APK at all.
