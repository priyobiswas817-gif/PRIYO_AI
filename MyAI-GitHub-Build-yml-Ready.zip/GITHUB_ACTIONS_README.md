# GitHub Actions

The workflow is located exactly at:

`.github/workflows/build.yml`

Before running it, create this GitHub Actions repository secret:

`GEMINI_API_KEY`

Then open:

GitHub → Actions → Build MyAI APK → Run workflow

The workflow builds a debug APK and uploads it as the `MyAI-APK` artifact.

Important: a GitHub Secret prevents the key from being stored in the repository, but if the Android app embeds the key into the APK, it may still be extractable from the APK. For maximum protection, keep the Gemini key on a backend.
