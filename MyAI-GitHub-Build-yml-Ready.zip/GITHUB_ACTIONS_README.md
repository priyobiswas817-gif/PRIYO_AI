# Fixed GitHub Actions workflow

This version does not require `gradlew` or `gradle-wrapper.jar`.
It installs Gradle 8.7 on the GitHub runner and runs:

`gradle assembleDebug --no-daemon`

Before building, create this repository secret:

`GEMINI_API_KEY`

GitHub -> Settings -> Secrets and variables -> Actions -> New repository secret.

The workflow file is:

`.github/workflows/build-apk.yml`

After a successful run, download `MyAI-APK` from the run's Artifacts section.

Security note: GitHub Secrets keep the key out of the repository, but this Android source currently passes the secret into BuildConfig, which means the final APK can potentially expose the key. For a truly protected production key, use a backend and keep the key server-side.
