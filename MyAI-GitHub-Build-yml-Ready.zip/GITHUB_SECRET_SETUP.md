# GitHub Secret setup

1. GitHub repository -> Settings -> Secrets and variables -> Actions.
2. New repository secret.
3. Name: GEMINI_API_KEY
4. Value: your NEW Gemini API key.
5. Actions -> Build MyAI APK -> Run workflow.

The workflow reads the secret and creates a temporary local.properties file only during the build.
The real key is not stored in the repository.

IMPORTANT:
A GitHub Secret protects the key from being committed to GitHub. If the Android app embeds the
key into the final APK, however, the key may still be extractable from the APK. For maximum
protection use a backend and keep the Gemini key server-side.
